//
//  ViewController.swift
//  encuesta_ulsa
//
//  Created by Alumno on 3/11/22.
//  Copyright © 2022 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblPersona: UILabel!
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var lblMatricula: UILabel!
    @IBOutlet weak var txtMatricula: UITextField!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var lblCorreo: UILabel!
    @IBOutlet weak var txtCorreo: UITextField!
    @IBOutlet weak var scTipoUsuario: UISegmentedControl!
    
    
    
    
    
    
    @IBOutlet weak var lblCuestionario: UILabel!
    @IBOutlet weak var lblP1: UITextView!
    @IBOutlet weak var lblP2: UITextView!
    @IBOutlet weak var lblP3: UITextView!
    @IBOutlet weak var btnP1: UISegmentedControl!
    @IBOutlet weak var btnFiebre: UISegmentedControl!
    @IBOutlet weak var btnEstomago: UISegmentedControl!
    @IBOutlet weak var btnGarganta: UISegmentedControl!
    @IBOutlet weak var btnMareo: UISegmentedControl!
    @IBOutlet weak var lblFiebre: UILabel!
    @IBOutlet weak var lblMareo: UILabel!
    @IBOutlet weak var lblEstomago: UILabel!
    @IBOutlet weak var lblGarganta: UILabel!
    @IBOutlet weak var btnP3: UISegmentedControl!
    @IBOutlet weak var btnTerminar: UIButton!
    
    
    
    
    
    
    
    
    @IBAction func DoTapTipo(_ sender: Any) {
        if (scTipoUsuario.selectedSegmentIndex == 0){
            lblMatricula.text = "Matricula"
            txtMatricula.placeholder = "Ingresa matricula"
        } else if (scTipoUsuario.selectedSegmentIndex == 1){
            lblMatricula.text = "Numero de profesor"
            txtMatricula.placeholder = "Ingresa numero de profesor"
        }else if(scTipoUsuario.selectedSegmentIndex == 2){
            lblNombre.text = "Empleado"
            txtMatricula.placeholder = "Ingresa numero de empleado"
        }
    }
    
    
    @IBAction func doTapSiguiente(_ sender: Any) {
        lblNombre.isHidden = true
        txtNombre.isHidden = true
        lblMatricula.isHidden = true
        txtMatricula.isHidden = true
        lblCorreo.isHidden = true
        txtCorreo.isHidden = true
        scTipoUsuario.isHidden = true
        lblPersona.isHidden = true
        btnNext.isHidden = true
        
        lblCuestionario.isHidden = false
        lblP1.isHidden = false
        lblP2.isHidden = false
        lblP3.isHidden = false
        btnP1.isHidden = false
        lblFiebre.isHidden = false
        btnFiebre.isHidden = false
        btnEstomago.isHidden = false
        btnGarganta.isHidden = false
        btnMareo.isHidden = false
        btnEstomago.isHidden = false
        lblGarganta.isHidden = false
        btnP3.isHidden = false
        lblMareo.isHidden = false
        btnTerminar.isHidden = false
        lblEstomago.isHidden = false
    }
    
    @IBAction func doTapTeminar(_ sender: Any) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        lblCuestionario.isHidden = true
        lblP1.isHidden = true
        lblP2.isHidden = true
        lblP3.isHidden = true
        btnP1.isHidden = true
        btnFiebre.isHidden = true
        btnEstomago.isHidden = true
        btnGarganta.isHidden = true
        btnMareo.isHidden = true
        btnEstomago.isHidden = true
        lblGarganta.isHidden = true
        btnP3.isHidden = true
        lblFiebre.isHidden = true
        lblMareo.isHidden = true
        lblEstomago.isHidden = true
        btnTerminar.isHidden = true
    }


}

